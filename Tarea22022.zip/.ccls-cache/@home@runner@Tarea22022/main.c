#include <stdio.h>
#include <stdlib.h>
#include "list.h"
#include "Map.h"
#include "treemap.h" //No se usa, pero el main no me permite quitarlo
#include <ctype.h>
#include <string.h>

//Estructuras
typedef struct{
  char nombre[2000];
  char marca[2000];
  char tipo[2000];
  int stock;
  int precio;
}producto;

//Funciones
void interfazMENU();
void ImportarProductos(Map*, List*);
void ExportarProductos(Map*, List*);
void AgregarProducto(Map*, List*);
void BuscarProductoNombre(Map*);
void mostrarProductos(List*);


char * _strdup(const char * str) {
    char * aux = (char *)malloc(strlen(str) + 1);
    strcpy(aux, str);
    return aux;
}

int lower_than_string(void* key1, void* key2){
    char* k1=(char*) key1;
    char* k2=(char*) key2;
    if(strcmp(k1,k2)<0) return 1;
    return 0;
}

int main(void) {
  List* L= create_list();
  Map* M= createMap(lower_than_string);
  int n;
  interfazMENU();
  printf("\n ¡Bienvenid@ a Lider!\n ¿Desea comprar algo?\n");
  scanf ("%d", &n); 
  while (n!=0) {
      switch (n){

        case 1: ImportarProductos(M, L); break;

        case 2: ExportarProductos(M, L); break;

        case 3: AgregarProducto(M, L); break;

        case 4: BuscarProductoNombre(M); break;
        
        case 7: mostrarProductos(L); break;

        default: printf("Opción incorrecta, por favor ingrese numero correcto\n"); break;
      }
      printf("\n¿Desea ultilizar otra operación?\n");
      scanf ("%d", &n);
    }
  clear(L); //Liberar el espacio usado
  printf("\n---------------------------------\n");
  printf("         Hasta la próxima       \n");
  printf("---------------------------------\n");
  return 0;
}


//FUNCION 1
void ImportarProductos(Map* M, List* L){
      char csv[4000];
      printf("\nIngrese nombre del archivo a Importar\n");
      scanf("%s", csv);
      FILE *Productos= fopen(csv, "r");

      if(Productos==NULL){
      printf("\nError al abrir el archivo\n");
      exit(EXIT_FAILURE);
      }
      producto* datos;
      int a, b, c;
      char AUXnombre[46];
      char AUXmarca[20];
      char AUXtipo[17];
  
      char datoProducto[4000];
  
      while(fscanf(Productos, "%3495[^\n]s", datoProducto)!=EOF){
        datos=(producto*) malloc(sizeof(producto));
        fgetc(Productos);
        
        //Aqui se guardaran los datos
        for (a=0; datoProducto[a]!=','; a++)
          AUXnombre[a]= datoProducto[a]; 
        a++;
          
        for (b=0; datoProducto[a]!=','; a++, b++)
          AUXmarca[b]= datoProducto[a]; 
        a++;
          
        for (c=0; datoProducto[a]!=','; a++, c++)
          AUXtipo[c]= datoProducto[a]; 
        a++;
          
        strcpy(datos->nombre, AUXnombre);
        strcpy(datos->marca, AUXmarca); 
        strcpy(datos->tipo, AUXtipo); 
        
        insertMap(M, datos->nombre, datos);
        push_back(L, datos);
        
        }
  
        printf("\n----------------------------\n");
        printf("Archivo leído exitosamente\n");
        printf("----------------------------\n");

        //Para asegurar que se cerro el archivo...
        if(fclose(Productos)==EOF) 
        printf("Error al cerrar el archivo\n");
}

//FUNCION 2
void ExportarProductos(Map* M, List* L){
    char csv[8000];
      producto* aux;
      printf("\nIngrese nombre su nuevo Archivo (.csv)\n");
      scanf("%s", csv);
      FILE *Productos2 = fopen(csv, "w"); //Crea un nuevo fichero en formato de escritura
      while(aux!=NULL){
        fprintf(Productos2, "%s  %s  %s", aux->nombre, aux->marca, aux->tipo);
        aux= next(L);
      }
  fclose(Productos2);
}

//FUNCION 3
void AgregarProducto(Map* M, List* L){
  producto* p=(producto*) malloc(sizeof(producto));
  producto* repit;
  char AUXnombre[20];
  char AUXmarca[20];
  char AUXtipo[20];
  getchar();
    printf("\nIngrese Nombre de su Producto: ");
    scanf("%s", AUXnombre); 
    repit= first(L);
    while(repit!=NULL){
      //Vamos a validar que no se añadira un producto ya agregado.
      if(strcmp(AUXnombre, repit->nombre)== 0){
        printf("Este Producto ya se encuentra en el catalogo\n");
        return AgregarProducto(M, L);
      }
      repit=next(L);
    }
    
    strcpy(p->nombre, AUXnombre);
    
    getchar();
    
    printf("\nIngrese Marca del producto: ");
    scanf("%[^\n]s", AUXmarca);
    strcpy(p->marca, AUXmarca);

    getchar();

    printf("\nIngrese el tipo de Producto: ");
    scanf("%[^\n]s", AUXtipo);
    strcpy(p->tipo, AUXtipo);

    getchar();
    insertMap(M, p->nombre, p);
    
    printf("\nProducto agregado al catalogo.\n");
}

//FUNCION 6
void BuscarProductoNombre(Map* M){
  producto* p= firstMap(M);
  char AUXnombre[46];

  printf("\nIngrese el tipo de su producto: \n");
  scanf("%s",AUXnombre);
  
  if (p==NULL){
    printf("\nNo se han encontrado productos\n");
  }
  else{
      p=searchMap(M, AUXnombre);
      if(p){
        printf("\nProducto  Marca\n");
        printf("%s   %s  %s", p->nombre, p->tipo, p->marca); 
      }else{
        printf("\nSu producto no se encuentra disponible\n");
      }
  }
  
}


//OPCION 7
void mostrarProductos(List* L){
    producto* aux= first(L);
    if(aux==NULL){ // se valida si existen canciones para mostrar
      printf("-----------------------------\n");
      printf("No se han encontrado productos, vuelva a intentarlo\n");
      printf("-----------------------------\n");
    }else{
      printf("Producto   Marca\n");
      while(aux!=NULL){
        printf("%s, %s, %s\n", aux->nombre, aux->marca, aux->tipo);
        aux= next(L);
      }
    }

}

void interfazMENU(){
  printf("\n  1) Importar Productos (csv)           \n");
  printf("\n  2) Exportar Productos                 \n");
  printf("\n  3) Agregar Producto                   \n");
  printf("\n  4) Buscar Producto (Tipo)             \n");
  printf("\n  5) Buscar Producto (Marca)            \n");
  printf("\n  6) Buscar Producto (Nombre)          \n");
  printf("\n  7) Mostrar todos los Productos        \n");
  printf("\n  8) Agregar al Carrito de Compra \n");
  printf("\n  9) Eliminar del Carrito           \n");
  printf("\n 10) Concretar compra (Carrito)      \n");
  printf("\n 11) Mostrar todos los Carritos de compra      \n");
  printf("\n  0) Salir                               \n"); 
}